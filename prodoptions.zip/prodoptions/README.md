ProdOptions module
=========

This is module for Dolibarr ERP/CRM to link product as an option.

Author
------

Aternatik - http://aternatik.fr

Licence
-------
GPLv3 

See COPYING for more information.

Other Licences
--------------
Uses Michel Fortin's PHP Markdown Licensed under BSD to display this README.
